<?php if (empty($fullWidth)): ?>
</div>
<?php endif; ?>
<footer>
    Desarrollado por: Technology and Innovation
</footer>
</body>
</html>
