<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <style>
        body { font-family: Arial, sans-serif; }
        h1 { text-align: center; }
        p { text-align: center; color: #374151; }
    </style>
</head>
<body>
<h1>Reporte de Cartera</h1>
<p>El PDF fue generado correctamente.</p>
</body>
</html>
