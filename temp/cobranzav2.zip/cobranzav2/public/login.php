<?php
header('Location: index.php?route=auth/login');
exit;
