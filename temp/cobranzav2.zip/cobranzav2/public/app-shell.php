<?php ?><!doctype html><html lang="es">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Sistema de Cartera</title>
<link rel="stylesheet" href="assets/css/global.css">
<script defer src="assets/js/app-shell.js"></script>
</head><body>
  <?php include __DIR__.'/includes/header.php'; ?>
  <div class="shell">
    <iframe id="appFrame" class="shell-iframe" title="Contenido"></iframe>
    <?php include __DIR__.'/includes/footer.php'; ?>
  </div>
</body></html>
